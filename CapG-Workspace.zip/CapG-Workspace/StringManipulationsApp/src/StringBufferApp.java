
public class StringBufferApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuffer strBuff = new StringBuffer("Hello,");
		System.out.println(strBuff);
		System.out.println("Length = "  +  strBuff.length() );
		
		//append() - concatenates a string 
		
		strBuff.append(" How are you?");
		
		System.out.println(strBuff);
		System.out.println("Length = "  +  strBuff.length() );
		
		//deleteCharAt() - deletes a character at a given index
		
		strBuff.deleteCharAt(0);
		
		System.out.println(strBuff);
		System.out.println("Length = "  +  strBuff.length() );
		
		strBuff.insert(0,"H");
		
		System.out.println(strBuff);
		System.out.println("Length = "  +  strBuff.length() );
		
		strBuff.delete(0,2);
		
		System.out.println(strBuff);
		System.out.println("Length = "  +  strBuff.length() );
		
		strBuff.reverse();
		System.out.println(strBuff);
		System.out.println("Length = "  +  strBuff.length() );
		
		//ratsdrowninwordstar
		
		strBuff.reverse();
		System.out.println(strBuff);
		System.out.println("Length = "  +  strBuff.length() );
		
		strBuff.insert(0, "He");
		System.out.println(strBuff);
		System.out.println("Length = "  +  strBuff.length() );
		
		System.out.println("Index of e - " + strBuff.indexOf("e"));
		
		
	}

}
