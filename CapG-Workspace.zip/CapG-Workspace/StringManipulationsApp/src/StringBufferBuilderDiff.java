
public class StringBufferBuilderDiff {

	public static void main(String[] args){  
		
        long startTime = System.currentTimeMillis();  // returns number of milli seconds lapsed from 1-1-1970 till current time
        
        StringBuffer sb = new StringBuffer("Java");  
        
        for (int i=0; i<20000; i++){  
            sb.append("hi");  
        }  
        
        System.out.println("Time taken by StringBuffer: " + (System.currentTimeMillis() - startTime) + "ms");  
        
        startTime = System.currentTimeMillis();  
        
        StringBuilder sb2 = new StringBuilder("Java");  
        
        for (int i=0; i<20000; i++){  
            sb2.append("hi");  
        }  
        System.out.println("Time taken by StringBuilder: " + (System.currentTimeMillis() - startTime) + "ms");  
    }  

}
