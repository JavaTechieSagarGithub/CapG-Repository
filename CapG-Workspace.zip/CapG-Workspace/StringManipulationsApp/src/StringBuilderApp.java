
public class StringBuilderApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder strBldr = new StringBuilder("Hello,");
		System.out.println(strBldr);
		System.out.println("Length = "  +  strBldr.length() );
		
		//append() - concatenates a string 
		
		strBldr.append(" How are you?");
		
		System.out.println(strBldr);
		System.out.println("Length = "  +  strBldr.length() );
		
		//deleteCharAt() - deletes a character at a given index
		
		strBldr.deleteCharAt(0);
		
		System.out.println(strBldr);
		System.out.println("Length = "  +  strBldr.length() );
		
		strBldr.insert(0,"H");
		
		System.out.println(strBldr);
		System.out.println("Length = "  +  strBldr.length() );
		
		strBldr.delete(0,2);
		
		System.out.println(strBldr);
		System.out.println("Length = "  +  strBldr.length() );
		
		strBldr.reverse();
		System.out.println(strBldr);
		System.out.println("Length = "  +  strBldr.length() );
		
		//ratsdrowninwordstar
		
		strBldr.reverse();
		System.out.println(strBldr);
		System.out.println("Length = "  +  strBldr.length() );
		
		strBldr.insert(0, "He");
		System.out.println(strBldr);
		System.out.println("Length = "  +  strBldr.length() );
		
		System.out.println("Index of e - " + strBldr.indexOf("e"));

	}

}
