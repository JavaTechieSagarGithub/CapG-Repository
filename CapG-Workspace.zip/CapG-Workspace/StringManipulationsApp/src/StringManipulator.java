
public class StringManipulator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = new String("Hello");
		
		int len = str.length();
		System.out.println("Length of the string " + len);
		char ch = str.charAt(2);
		System.out.println(ch);
		int index = str.indexOf('o');
		System.out.println(index);
        String str2 =   str.concat(" World");// Hello World
        
        System.out.println("str2 - " + str2);
        System.out.println("str - " + str);
        
        System.out.println( str.contains("LL") );
        
        boolean isSame;
        isSame = str.equals("hello");
        System.out.println("str equals Hello - " + isSame);
        
        isSame = str.equalsIgnoreCase("hello");
        System.out.println("str equals ignore case -  Hello - " + isSame);
        
        //substring - extracts a string from a given string
        String str3 = "How are you?";
        
        String substr = str3.substring(4,7);
        System.out.println( substr);
        
        //split - string will be splitted based on the delimiter and stores in an String array
        
        String spltStr[];
        
        spltStr = str3.split(" ");// space is the delimiter
        
        for(String word : spltStr) { // for each loop 
        	System.out.println( word );
        }
        
      System.out.println( str3.startsWith("how"));
      System.out.println( str3.endsWith("?"));
      
      String str4 =  "Welcome" ;
      String str5 = str4;
      
      System.out.println( str5.equals(str4));
      
      String str6 ="Welcome"; 
      String str7 = new String("Welcome");
      System.out.println("comparison with == operator");
      boolean isTrue = str4==str5;
      System.out.println( "str4 == str5   " + (str4==str5) );
      System.out.println( "str6 == str7   " + (str6==str7) );
      System.out.println("str6.equals(str7)");
      System.out.println( str6.equals(str7));
	}

}
