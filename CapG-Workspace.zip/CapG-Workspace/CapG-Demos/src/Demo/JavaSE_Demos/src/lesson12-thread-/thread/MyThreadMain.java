package com.capgemini.lesson10.thread;

public class MyThreadMain {

	public static void main(String[] args) {
		

		MyThread thread1=new MyThread("FirstThread");
		
	   thread1.start();
	   
	
	}

}
