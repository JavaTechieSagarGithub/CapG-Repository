package com.cg.sms.exceptions;

public class SMSException extends Exception {

	public SMSException(String message) {
		super(message);
	}
}
