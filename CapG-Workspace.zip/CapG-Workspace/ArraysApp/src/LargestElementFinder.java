import java.util.Scanner;

public class LargestElementFinder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		float scores[] = new float[10];
		// instance constant - arrayname.length - size of the array
		float max;
		for(int index=0; index<scores.length; index++) {
			System.out.println( scores[index]);
		}
		//input elements into array
		
		for(int index=0; index<scores.length; index++) {
			System.out.println("Enter the value of scores[" + index + "]");// Enter the value of scores[0]
			scores[index]  = scnr.nextFloat();
		}
		System.out.println("Array elements are :");
		for(int index=0; index<scores.length; index++) {
			System.out.println( scores[index]);
		}
		max = scores[0];
		for(int index=1; index<scores.length; index++) {
			if( scores[index] > max ) {
				max = scores[index];
			}
		}
		System.out.println("Largest element is " + max);
	}

}
