import java.util.Scanner;

public class EvenElementSumFinder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		// store 1st 10 fibonacci series into an array
		// user array name and index as variables 
		int fibo[] = new int[10];
		int index;
		// 0 1 1 2 3 5 8 13 21 34
		fibo[0]=0;
		fibo[1]=1;
		System.out.println(fibo[0]);
		System.out.println(fibo[1]);
		// fibo[2] = fibo[0] + fibo[1];
		for(index = 2; index < fibo.length; index++) {
			fibo[index] = fibo[index-2] + fibo[index-1];
			System.out.println(fibo[index]);
		}
	}
}
