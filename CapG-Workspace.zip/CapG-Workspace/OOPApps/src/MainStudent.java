
public class MainStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Address address = new Address("25-3-5","12","Ramnagar","Pune",475869);
		Student anirudh = new Student(1001,"Anirudh Pandy","B.Tech",address);
		System.out.println(anirudh.getRollNo());
		System.out.println(anirudh.getName());
		System.out.println(anirudh.getCourse());
		
		System.out.println(anirudh.getAddress().getDno());
		//System.out.println(anirudh.school);
		System.out.println(anirudh.getSchool());
		//System.out.println(anirudh.name);
	}

}
