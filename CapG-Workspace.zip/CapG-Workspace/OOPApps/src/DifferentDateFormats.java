
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DifferentDateFormats {

  public static void main(String args[]) {

  String str;
  Format formatter;
  Date date = new Date(); // current date
  System.out.println("Today without format " + date );
  
  formatter = new SimpleDateFormat("MM/dd/yy");
  str = formatter.format(date);// returns date in String format
  System.out.println(str);

  formatter = new SimpleDateFormat("dd/MM/yy");
  str = formatter.format(date);
  System.out.println(str);

  
  formatter = new SimpleDateFormat("dd-MMM-yy");
  str = formatter.format(date);
  System.out.println(str);

  formatter = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
  str = formatter.format(date);
  System.out.println(str);


  formatter = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss");
  str = formatter.format(date);
  System.out.println(str);

  formatter = new SimpleDateFormat("EEEE, dd MMMM yyyy HH:mm:ss zzzz");
  str = formatter.format(date);
  System.out.println(str);
  
  
  
  }
}