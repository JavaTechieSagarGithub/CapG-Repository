public class MyApp {
	public MyApp() {
		System.out.println("ZeroParameter Consatructor");
	}

	public MyApp(int a) {
		System.out.println("Parameter Constructor");
		this();
	}

	public void callConstruct() {
		this(10);
	}

	public static void main(String[] ar) {
		new MyApp().callConstruct();
	}
}