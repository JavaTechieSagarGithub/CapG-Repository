
public class BankAccount {
	// variables
	//final - variables values can not be modified
	final int acntNo=25631452;
	static final String acntType = "Savings Bank";
	static final String	bankName = "HDFC Bank";
	float balance;
	
	// methods
	public void assignValues() {
		
		balance = 500000.00f;
	}
	
	public void deposit(float amount) {
		balance += amount;
	}
	
	public void showBalance() {
		System.out.println("Current Balance = "  + balance);
	}
	
	public void showBankName() {
		System.out.println(bankName);
		//bankName="ICICI Bank";
	}

}
