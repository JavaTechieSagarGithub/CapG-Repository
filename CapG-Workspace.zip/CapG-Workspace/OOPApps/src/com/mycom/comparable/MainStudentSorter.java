package com.mycom.comparable;
import java.util.Arrays;
import java.util.Scanner;
public class MainStudentSorter {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		Student[] students = new Student[4];
		// create objects and store in array
		for( int index=0; index < students.length ; index++ ) {
			System.out.println("Enter Student " + (index+1) + " Details");
			int age;
			String name;
			System.out.println("Enter Name ");
			name = scnr.nextLine();
			System.out.println("Enter Age ");
			age = scnr.nextInt();
			scnr.nextLine();
			students[ index ] = new Student( name, age );
		}
		
		
		Arrays.sort(students);
		
		for( Student student : students ) {
			System.out.println( student.getAge() + "    " +  student.getName() + "\n" );
		}
	}

}
