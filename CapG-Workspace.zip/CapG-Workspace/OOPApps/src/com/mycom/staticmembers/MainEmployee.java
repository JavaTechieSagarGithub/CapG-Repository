package com.mycom.staticmembers;

public class MainEmployee {
	public static void main(String[] args) {
		
		//calling static method
	     Employee.assignCompanyName(); 
	     //creating objects 
	     Employee kushal = new Employee(218,"Kushal"); 
	     Employee bhumika = new Employee(635,"Bhumika"); 
	     Employee nesha = new Employee(147,"Nesha"); 
	     System.out.println("Emp Id\tEmp Name\tCompany");
	     System.out.println("----------------------------------");
	     //calling display method 
	     kushal.display(); 
	     bhumika.display(); 
	     nesha.display(); 
	
	}
}
