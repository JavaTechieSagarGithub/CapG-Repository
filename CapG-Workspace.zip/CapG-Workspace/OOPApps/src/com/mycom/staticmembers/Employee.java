package com.mycom.staticmembers;

public class Employee {
	int empId; 
	String empName; 
	static String companyName; 
	//static method to assign the value of static variable 
	static void assignCompanyName(){ 
		companyName = "CapGemini"; 
	} 
	//constructor to initialize the variable 
	Employee(int id, String name){ 
		empId = id; 
		empName = name; 
	} 
	//method to display values 
	void display(){
		System.out.println(empId+"\t"+empName+"\t\t"+companyName);
	} 
	
	 
}
