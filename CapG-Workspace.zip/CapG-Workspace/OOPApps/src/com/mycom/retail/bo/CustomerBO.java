package com.mycom.retail.bo;

import com.mycom.retail.pojo.Customer;

public class CustomerBO {

	public void showCustomerDetails(Customer customers[]) {
		System.out.println("Customers details");
		for (int index = 0; index < customers.length; index++) {
			System.out.println(customers[index].getId());
			System.out.println(customers[index].getName());
			System.out.println(customers[index].getBillAmount());
		}
		
		for(Customer customer : customers) {
			System.out.println(customer.getId());
			System.out.println(customer.getName());
			System.out.println(customer.getBillAmount());
		}
	}

}
