package com.mycom.retail.pojo;
public class Customer {
	int id;
	String name;
	float billAmount;
	
	public Customer(int id, String name, float billAmount) {
		super();
		this.id = id;
		this.name = name;
		this.billAmount = billAmount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(float billAmount) {
		this.billAmount = billAmount;
	}

}
