package com.mycom.retail.presentation;

import java.util.Scanner;

import com.mycom.retail.bo.CustomerBO;
import com.mycom.retail.pojo.Customer;

public class MainCustomerArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customers[] = new Customer[5];// references of Customer objects are created not objects
		Scanner scnr = new Scanner(System.in);
		
		for(int index=0; index<customers.length; index++) {
			
			int id;
			String name;
			float billAmount;
			System.out.println("Enter customer id");
			id = scnr.nextInt();
			scnr.nextLine();// takes the enter key input from previous line
			System.out.println("Enter customer name");
//			name = scnr.next();// accepts a single word
			name = scnr.nextLine();// will accept multiple words in the string
			System.out.println("Enter customer bill amount");
			billAmount = scnr.nextFloat();
			//create objects
			customers[index] = new Customer(id,name,billAmount);	
			
		}
		/*System.out.println("Customers details");
		for(int index=0; index<customers.length; index++) {
			System.out.println(customers[index].getId());
			System.out.println(customers[index].getName());
			System.out.println(customers[index].getBillAmount());
		}*/
		CustomerBO customerBo = new CustomerBO();
		customerBo.showCustomerDetails(customers);
	
	}

}
