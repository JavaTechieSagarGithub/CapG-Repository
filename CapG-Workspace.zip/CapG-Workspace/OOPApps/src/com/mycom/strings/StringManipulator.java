package com.mycom.strings;

public class StringManipulator {

public static void main(String[] args) {
		
		String str1 = "Success is ... people searching for u in google but not in facebook";
		System.out.println( str1 );
		
		//charAt() - returns character at a given index
		char ch = str1.charAt(3); // second 'c' in Success
		System.out.println( ch );
		//lenth() - 
		int len = str1.length();
		System.out.println("String length =  "  + len );
		
		String strLower = str1.toLowerCase(); // return the string in lowercase
		String strUpper = str1.toUpperCase();
		System.out.println(  "Lower case String " + strLower  +  "\t" + "Upper Case String " + strUpper);
		
		System.out.println(  "Original String   "  + str1  );// will not modify - immutable
		
		System.out.println(    str1.toLowerCase()    );
		System.out.println(str1);
		
		
		
		
		
		String str2 = "Hello";
		String str3 = "Hello"; // referencing to str2 object - single object
		
		if( str2 == str3 ) { 
			System.out.println("Both are referencing to same string object");
		}  else {
			System.out.println("Both strings are different");
		}
	
		String str4 = new String("Hello");
		String str5 = new String("Hello");
		
		if( str4 == str5 ) { // false - not referencing to the same String object
			System.out.println("Both are referencing to same string object");
		}  else {
			System.out.println("Two string objects referred by two  references ");
		}
		
		
		
		
		
		
		
		/*

		String str4 = new String("Hello10");
		String str5 = new String("hello11");
		
		if( str2 == str4 ) {
			System.out.println("Both strings are same");
		}  else {
			System.out.println("Both strings are different");
		}
		if( str5 == str4 ) {
			System.out.println("Both strings are same");
		}  else {
			System.out.println("Both strings are different");
		}*/
		
		// equals() -- compare the contents of the strings
		// argument of equals() method is one object
		
		if( str2.equals(str3)   ) {
			System.out.println("Both strings are same");
		}  else {
			System.out.println("Both strings are different");
		}
		
		if( str4.equals(str5)   ) {
			System.out.println("Both strings are same");
		}  else {
			System.out.println("Both strings are different");
		}
		// equalsIgnoreCase() - ignores the case sensitivity and compares the string
		
		
		if( str4.equalsIgnoreCase(str5)   ) {
			System.out.println("Both strings are same");
		}  else {
			System.out.println("Both strings are different");
		}
		
		String concatStr,concatStr2,wish;
		
		concatStr = "Hello " + "World";
		wish = "Hello ";
		concatStr2 = wish.concat("World");
		
		System.out.println( "Concatenated string with +  " + concatStr);
		
		System.out.println( "Concatenated string with concat() method  " + concatStr2);
			
		
		//concat() - concatenate(joins) a string to the original string
		
		String str6 = new String("Hello");
		String str7 = new String( "       How Are You?");
		System.out.println(    str6.concat( str7 ) );// creates an intermediate string object
		
		System.out.println("str6 = " + str6);		

		//contains() - determines whether a string is available in another string and returns true if available .... false if not
		
		System.out.println(   str7.contains(  "Are"   )   ); // true
		
		// startsWith() - returns true if a string starts with another string
		
		System.out.println( str7.startsWith(" "));//true
		System.out.println( str7.endsWith(  "ou?" )   );//true
	
		// substring() - returns specific characters from a given string starting from an index upto given index
		//Success is ... people searching for u in google not in facebook;
		System.out.println(   str1.substring(3, 7 )    );// 3 is the beginning character index  7 upto index - not including index 7
				
		 String str = "Success is ... people searching for u in google not in facebook";
		
		
		// split() - splits the string into a String[] array.
		
		String spltStr[] = str.split(" ");// space is delimiting character
		//spltStr[0] - Success
		//spltStr[1] - is
		//spltStr[2] - 	...	//
		//spltStr[3] - people
		//spltStr[4]-searching
		
		System.out.println(   spltStr.length  );
			
		for( String word : spltStr ) {
			System.out.println( word );
		}
		System.out.println(" The string str -  "  + str);
		
		// employee details are in the form of a string
		
		String empDetails = "1001,Nesha,65321.25";
		
		String empStr[] = empDetails.split(",");
		//empStr[0] - 1001
		//empStr[1] - Nesha
		//empStr[2] - 65321.25
		
		for( String data : empStr ) {
			System.out.println( data );
		}
		
	
		String name="Sagar";
		String sfmtName = String.format("%15s",name);
		System.out.println(sfmtName);
		String sfmtName2 = String.format("%15s","Vidya Sagar");			
		System.out.println(sfmtName2);
		float num1=123.45f;
		float num2 = 12.456f;
		System.out.println(String.format("%7.2f",num1));
		System.out.println(String.format("%7.2f",num2));
		System.out.println(num1);
		System.out.println(num2);
}

}