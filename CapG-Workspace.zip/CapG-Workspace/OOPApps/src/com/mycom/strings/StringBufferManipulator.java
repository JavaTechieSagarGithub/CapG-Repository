package com.mycom.strings;

import java.util.Scanner;

public class StringBufferManipulator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer strBuf = new StringBuffer( "Hello " );// StringBuffer is mutable 
		
		System.out.println( strBuf );
		
		strBuf.append("how " ); // Hello how 
		System.out.println( strBuf );
		
		strBuf.append("are you?"); // // Hello how are you?
		System.out.println( strBuf );
		
		System.out.println( strBuf.length() );
				
		//delete a character   deleteCharAt()
		strBuf.deleteCharAt( 4 );
		System.out.println( strBuf );
		System.out.println( strBuf.length()  );
		
			
		strBuf.insert(4, "o");
		System.out.println( strBuf );
		strBuf.insert(5, ",CapGemini Techies,");
		System.out.println(strBuf);
			
	
		strBuf.delete(6,8);
		System.out.println( strBuf );
		
		strBuf.replace(0,5 , "Hi");
		System.out.println( strBuf );
		
		// reverse() -  reveses the string
		
		strBuf.reverse();
		System.out.println( strBuf );
		
	}
}

		
		
		
		
		
		
		
		
		
		
		
		
		/*
		
		
		
		
		Scanner scnr = new Scanner(System.in);
		//StringBuffer originalStr = new StringBuffer( scnr.nextLine() );
		String str = scnr.nextLine();
		StringBuffer originalStr = new StringBuffer( str );
		StringBuffer duplStr = new StringBuffer(originalStr);
		StringBuffer revStr = originalStr.reverse();
		
		System.out.println( "Original string " + originalStr +  " Reversed String" + revStr + "Duplicate String " + duplStr );
		
		
		// StringBuffer can be converted into String objects - toString()
		if( duplStr.toString().equalsIgnoreCase(  revStr.toString())  ) {
			System.out.println("Palindrome");
		} else {
			System.out.println("Not Palindrome");
		}
	}

}
		
*/