
public class MainArithmeticOps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArithmeticOperations arithOps = new ArithmeticOperations();
		arithOps.add(12.5f, 63.25f);
		arithOps.add(12, 63);
	}

}
