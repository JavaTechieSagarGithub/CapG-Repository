import com.mycom.retail.pojo.Customer;

public class MainCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*Customer kumar = new Customer(1001,"Rakesh Kumar", "rakesh@gmail.com",9876543210L);
		Customer saadhvik = new Customer(1002,"Saadhvik", "sadhvik@gmail.com",8885475876L);
		
		System.out.println( kumar.getId() );
		System.out.println( kumar.getName() );
		System.out.println(saadhvik.getName());
		saadhvik.setName("Saadhvik Arora");
		System.out.println(saadhvik.getName());
		*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*System.out.println(kumar);
		System.out.println(saadhvik);*/
	}

}
