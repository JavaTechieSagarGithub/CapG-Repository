	
public class Address {
	private String dno;
	private String roadNo;
	private String locality;
	private String city;
	private int pinCode;
	public String getDno() {
		return dno;
	}
	public void setDno(String dno) {
		this.dno = dno;
	}
	public String getRoadNo() {
		return roadNo;
	}
	public Address(String dno, String roadNo, String locality, String city, int pinCode) {
		super();
		this.dno = dno;
		this.roadNo = roadNo;
		this.locality = locality;
		this.city = city;
		this.pinCode = pinCode;
	}
	public void setRoadNo(String roadNo) {
		this.roadNo = roadNo;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
}
