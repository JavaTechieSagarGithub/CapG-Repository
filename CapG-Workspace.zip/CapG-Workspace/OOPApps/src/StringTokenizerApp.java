import java.util.StringTokenizer;
public class StringTokenizerApp {

	public static void main(String[] args) {
		StringTokenizer st1 = new StringTokenizer("Hello Folks How are you", " ");

		// Condition holds true till there is single token
		// remaining using hasMoreTokens() method
		while (st1.hasMoreTokens()) {

			// Getting next tokens
			System.out.println(st1.nextToken());
		}
		StringTokenizer st2 = new StringTokenizer("200 500 600 450 690", " ");

		int sum=0;
		while (st2.hasMoreTokens()) {
			
			sum = sum + Integer.parseInt(st2.nextToken());
			
			
		}
		System.out.println("Sum = " + sum);
	}

}
