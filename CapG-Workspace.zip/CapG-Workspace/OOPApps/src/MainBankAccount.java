
public class MainBankAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount sbAccount = new BankAccount(); // to create object
		// class name  - reference             constructor-creates an object
		sbAccount.assignValues();
		sbAccount.showBalance();
		
		sbAccount.deposit(50000.00f);
		sbAccount.deposit(50000.00f);
		sbAccount.showBalance();
		
		
	}

}
