public class WrapperClassesDemo {

	public static void main(String[] args) {

		int num = 1234;
		String str1 = Integer.toString(num);

		System.out.println("Number of digits " 
				+ str1.length());

		Integer inum = Integer.valueOf("1234567");
			

		System.out.println( inum 
				+ " Using Integer.valueOf()");
	
		String strInum = inum.toString();
		System.out.println("1234567 has " 
		            + strInum.length() + "digits");
		
		int num2;

		num2 = Integer.parseInt("255");

		System.out.println(num2 
				+ " Using Integer.parseInt()");
		
		float fltnum = Float.valueOf("255.22");	
	
		Integer val1 = new Integer(25);

		Integer val2 = new Integer(24);

		int diff = val1.compareTo(val2);
		// compare values using API ....
		//not by using if numbers directly .
		//.. important for objects handling
			
		if(diff>0) {
			System.out.println(val1 + " is large");
		} else  if(diff<0) {
			System.out.println(val2 + " is large");
		} else {
			System.out.println("Both are equal");
		}
				
		Float salary = new Float(12345.67f);

		int sal = salary.intValue();

		System.out.println("Salary is "+ salary 
				+" Integer salary is "  + sal);
		boolean salCheck = salary.isNaN();
		// salary is a number
		System.out.println(salCheck);

		
		String hexString = Integer.toHexString(255);  
		
		System.out.println(
			"Decimal no - 255\nHexadecimal string is " 
		    + hexString);

	}

}

























