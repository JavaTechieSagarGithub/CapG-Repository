
public class UnaryOpertorsApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=10;
		num++;
		System.out.println(++num);
		
		System.out.println(++num + num++);
		System.out.println(num);
		System.out.println(++num + num++ + ++num + num + 1);
		// displaying command line arguments
		System.out.println(args[0] + "  " + args[1] + "  " + args[2]);
	}

}
