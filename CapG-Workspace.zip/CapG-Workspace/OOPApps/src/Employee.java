
public class Employee {
	
	int id;
	String name,job;
	long mobilePhoneNo;
	float salary;
	
	static String companyName;
	static long  tollFreeNumber;
	
	// constructor with arguments
	Employee(int id, String name, String job, long mobilePhoneNo, long tollFreeNumber, float salary,String companyName) {
		this.id=id;
		this.name=name;
		this.job=job;
		this.mobilePhoneNo = mobilePhoneNo;
		Employee.tollFreeNumber = tollFreeNumber;
		this.salary = salary;
		Employee.companyName = companyName;
		
	}
	public void showEmpDetails() {
		
		System.out.println(id);
		System.out.println(name);
		System.out.println(job);
		System.out.println(mobilePhoneNo);
		System.out.println(salary);
		System.out.println(companyName);
		System.out.println(tollFreeNumber);
	}
	
	

}
