
public class MainEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*Employee kumar = new Employee();/
		Employee nesha = new Employee();
		*/
		/*System.out.println(kumar.id);
		System.out.println(nesha.id);
		System.out.println(nesha.name);// not "nesha"
		System.out.println(kumar.salary);*/
		
		Employee kumar = new Employee(1001,"Prasanna Kumar","Manager",9698979593L,1800223344L,65321.25f,"HCL Tech");
		kumar.showEmpDetails();
		Employee anirudh = new Employee(1002,"Anirudh","Manager",9698979716L,1800223344L,67321.25f,"HCL Tech");
		anirudh.showEmpDetails();
	}

}
