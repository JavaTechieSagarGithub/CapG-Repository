import java.util.Scanner;

public class ScoresManipulatorDdArray {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		float scores[][] =  new float[3][4];
		System.out.println("Enter scores details");
		
		for(int row=0; row<3; row++) {
			for(int column=0; column<4; column++) {
				System.out.println("Enter score of match "+ (row+1) + "Player "+ (column+1));
				scores[row][column] = scnr.nextFloat();
			}
		}
		for(int row=0; row<3; row++) {
			for(int column=0; column<4; column++) {
				System.out.print(scores[row][column] + "\t");
				
			}
			System.out.println();
		}
	}

}
