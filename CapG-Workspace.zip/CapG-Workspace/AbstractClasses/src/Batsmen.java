class Batsmen extends Player
{
    int numberOfCenturies;
    int numberOfHalfCenturies;

    Batsmen(String name, int matchesPlayed, int runsScored, int numberOfCenturies, int numberOfHalfCenturies)
    {
        super(name, matchesPlayed, runsScored);
        this.numberOfCenturies = numberOfCenturies;
        this.numberOfHalfCenturies = numberOfHalfCenturies;
    }

    void openInnings()
    {
    	
    	/** this methods reflectes on inning openings*/
    }

    void makeCentury()
    {
    }
    
    void makeHalfCentury()
    {
    }

    void print()
    {    
        super.print();
        System.out.print(" He is a strong batsmen and made " + numberOfCenturies +  " centuries and " + numberOfHalfCenturies + " half centuries.");
    }
}
