
public class MainShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Square square = new Square();
		System.out.println("Area of Square");
		square.computeArea(6.0f);
		square.showArea();
		
		
		Rectangle rect = new Rectangle();
		System.out.println("Area of Rectangle");
		rect.computeArea(6);
		rect.showArea();
		
		/*Circle circle = new Circle();
		circle.computeArea(2.0f);
		System.out.println("Area of Circle :");
		circle.showArea();*/
	}

}
