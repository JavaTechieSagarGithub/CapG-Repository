class Bowler extends Player { 
	int numberOfWickets; int
  numberOf5WicketInnings;

  Bowler(String name, int matchesPlayed, int runsScored, int numberOfWickets,
  int numberOf5WicketInnings) { super(name, matchesPlayed, runsScored);
  this.numberOfWickets= numberOfWickets; this.numberOf5WicketInnings =
  numberOf5WicketInnings; }
  
  void openInnings() { }
  
  void bowlYorkers() { }
  
  void takeWickets() { }
  
  void print() { super.print();
  System.out.print(" He is also a good bowler and has taken " + numberOfWickets
  + " wickets. He has " + numberOf5WicketInnings +
  " 5WI(5-Wicket Innings) in his account."); }
  
  }