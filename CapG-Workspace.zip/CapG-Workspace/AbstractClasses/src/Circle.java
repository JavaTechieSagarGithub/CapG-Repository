
public class Circle extends Shape {
		
	@Override
	public void computeArea(float param) {
	
		super.param = param;
		// Math.PI returns double type
		area = (float) (Math.PI * super.param * super.param );// param is radius
			
	}

}
