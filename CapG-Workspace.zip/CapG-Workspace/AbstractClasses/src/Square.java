
public class Square extends Shape {

	@Override
	public void computeArea(float param) {
		super.param=param;
		area = super.param * super.param;
	}
	

}


