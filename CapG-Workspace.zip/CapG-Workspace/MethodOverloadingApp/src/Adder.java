
public class Adder {
	public void add(int inum1, int inum2) {
		int isum=0;
		isum = inum1 + inum2;
		System.out.println("isum in add(int inum1, int inum2) " + isum);

	}

	public void add(float fnum1, float fnum2) {
		float fsum=0.0f;
		fsum = fnum1 + fnum2;
		System.out.println("fsum in add(float fnum1, float fnum2)"  + fsum);
	}

	public void add(int inum1, int inum2, int inum3) {
		int isum=0;
		isum = inum1 + inum2 + inum3;
		System.out.println("isum in add(int inum1, int inum2, int inum3) " + isum);
	}
}
