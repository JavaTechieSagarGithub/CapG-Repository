
public class MainAdder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Adder adder = new Adder();
		adder.add(20, 30);
		adder.add(20.25f, 38.36f);
		adder.add(56,69,30);
	}

}
