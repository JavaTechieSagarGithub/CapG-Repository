package com.mycom.superclass;

public class MainProtected {

	public static void main(String[] args) {

		Employee emp = new Employee();
		emp.showEmployeeDetails();
		

	}

}
