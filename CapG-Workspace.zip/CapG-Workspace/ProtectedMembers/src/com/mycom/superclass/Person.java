package com.mycom.superclass;

public class Person {
	
	  public String fname = "Krishna "; // public String fname="Krishna"
	  protected String lname = "B M";
	  protected String email = "krishna@gmail.com";
	  protected int age = 24;

}
