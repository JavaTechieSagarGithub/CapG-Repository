package com.mycom.superclass;

public class Employee  { //can access protected members of  Person
	
	public void showEmployeeDetails() {
		
		Person person = new Person();
		System.out.println( person.fname ); 
		System.out.println( person.lname );
		System.out.println( person.email );
		System.out.println( person.age );
		
	}
}
