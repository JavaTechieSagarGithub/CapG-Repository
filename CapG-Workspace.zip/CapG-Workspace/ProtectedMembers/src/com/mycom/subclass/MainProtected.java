package com.mycom.subclass;

public class MainProtected {

	public static void main(String[] args) {

		Student student = new Student();
		System.out.println("Student details");
		student.showStudentDetails();
		
		Employee employee = new Employee();
		System.out.println("Employee Details");
		employee.showEmployeeDetails();
		
	}

}
