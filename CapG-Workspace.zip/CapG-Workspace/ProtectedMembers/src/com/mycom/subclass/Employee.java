package com.mycom.subclass;

import com.mycom.superclass.Person;

public class Employee extends Person {
	
	public void showEmployeeDetails() {
		
	   System.out.println( fname ); 
	   
		System.out.println( lname );
		System.out.println( email );
		System.out.println( age );
	}
}
