package com.mycom.subclass;

import com.mycom.superclass.Person;

public class Student extends Person { // can access protected member of Person 
	
	public void showStudentDetails() {
		
		System.out.println( fname ); // can access fname as it is protected and Student is subclass of Person of another package
		System.out.println( lname );
		System.out.println( email );
		System.out.println( age );
	}
}
