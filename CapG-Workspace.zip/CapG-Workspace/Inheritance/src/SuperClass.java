
public class SuperClass {
	int num;
	String city;
	SuperClass(String city) {
		this.city = city;
		System.out.println("In SuperClass() constructor");
		System.out.println("City in SuperClass "  + this.city);
	}
	public void showNum() {
		num=25;
		System.out.println("showNum() of SuperClass "  + num); 
		
	}
}
