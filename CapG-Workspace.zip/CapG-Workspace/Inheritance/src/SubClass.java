
public class SubClass extends SuperClass {
	int sum=10;
	String city,state;
	SubClass(String city, String state) {
		super(city);
		this.city = city;
		this.state = state;
		System.out.println("In SubClass() constructor");
		System.out.println("City and State in SubClass "  + this.city + "\t\t" + this.state);
	}
	
	public void showSum() {
		super.showNum();
		sum = sum+super.num;
		System.out.println("showSum() of SubClass "  + sum); 
		
	}
}
