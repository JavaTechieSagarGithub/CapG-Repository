
public class MainInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SuperClass supClass = new SuperClass("Pune");
		SubClass subClass = new SubClass("Hyderabad","Telangana");// super class constructor executes first
		//supClass.showNum();
		//subClass.showSum();
	}

}
