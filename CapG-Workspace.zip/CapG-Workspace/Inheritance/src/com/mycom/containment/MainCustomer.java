package com.mycom.containment;

public class MainCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Address address =
				new Address("12-6-9/A", "Road No. 1", "Hebbal", "Bangalore");
		
		Customer customer = new Customer();
		customer.setId(1001);
		customer.setName("Fedrick");
		customer.setAddress(address);
		
		System.out.println(customer.getId() + customer.getName());
		
		System.out.println( customer.getAddress().getHouseNo() );
		System.out.println( customer.getAddress().getStreet() );
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
;