package com.mycom.inheritance;

public class RDAccount extends BankAccount {
	int tenure;
	
	RDAccount(int acntNo,String acntType,	float balance, int tenure) {
		super(acntNo, acntType,balance);
		this.tenure = tenure;
	}
	
	public void showTenure() {
		System.out.println("Tenure of RD Account is "  + tenure + " months");
	}
	
	public void updateBalance(float percentOfInterest) {
		float interestAmount;
		interestAmount = balance * percentOfInterest /12;
		balance = balance + interestAmount;
	}

}
