package com.mycom.inheritance;

public abstract class Shape {
	int param;
	float area;
	
	public abstract void computeArea();// method declaration / method signature
	
	public void showArea() { // concrete method
		System.out.println("Area = "  + area );
	}

}
