package com.mycom.inheritance;



public class MainEmployees {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee kumar = new Employee(1001,"Kumar",36532.12f);
		Manager prakash = new Manager(1005, "Prakash",45263.25f,25);
		
		kumar.login();
		kumar.logout();
		
		prakash.login();
		prakash.logout();
		
		kumar.computeHra();
		prakash.computeHra(); // will be of 45% on salary
		
		prakash.showTeamSize();
		kumar.showEmpDetails();
		
		prakash.showManagerDetails();
		System.out.println("Using toString() method");
		System.out.println(kumar);
		

		
		
		
		
	}

}
