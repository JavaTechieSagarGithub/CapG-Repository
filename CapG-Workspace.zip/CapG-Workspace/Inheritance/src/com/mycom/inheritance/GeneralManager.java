package com.mycom.inheritance;

public class GeneralManager  extends Manager {
	
	int managersCount;
	GeneralManager(int id, String name, float salary, int teamSize, int managersCount) {
		super(id, name, salary, teamSize);
		this.managersCount = managersCount;
	}

	public void showManagersCount() {
		System.out.println( managersCount);
	}
	// over ride computeHra() - hdra - 40% of salary
}
