package com.mycom.inheritance;

public class Circle extends Shape {
	int radius;
	
	@Override
	public void computeArea() {
		// TODO Auto-generated method stub
		param = 2;
		radius = param;
		area = (float) (Math.PI * radius * radius);
		
	}
	
}
