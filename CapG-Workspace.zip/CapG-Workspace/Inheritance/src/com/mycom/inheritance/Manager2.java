package com.mycom.inheritance;

public class Manager2 {

}
