package com.mycom.inheritance;

public class BankAccount {
	int acntNo;
	String acntType;
	float balance;
	
	BankAccount(int acntNo,	String acntType,	float balance) {
		this.acntNo = acntNo;
		this.acntType = acntType;
		this.balance = balance;
	}
	public void updateBalance(float percentOfInterest) {
		balance = balance + balance * percentOfInterest;
	}
	
	public void showBalance() {
		System.out.println("Balance = "  + balance);
	}
}
