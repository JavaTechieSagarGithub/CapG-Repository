package com.mycom.inheritance;

public interface IShape {
	
	void computeArea();
	void showArea();
	

}
