package com.mycom.inheritance;

public class MainShapes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*Circle circle = new Circle();
		circle.computeArea();
		circle.showArea();
		
		Rectangle rectangle = new Rectangle();
		rectangle.computeArea();
		rectangle.showArea();
		// create objects of implemented interface
*/		
		MyCircle circle2 = new MyCircle();
		MyRectangle rectangle2 = new MyRectangle();
		circle2.computeArea();
		circle2.showArea();
		
		rectangle2.computeArea();
		rectangle2.showArea();
	}

}
