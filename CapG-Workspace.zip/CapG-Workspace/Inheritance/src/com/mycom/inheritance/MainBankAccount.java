package com.mycom.inheritance;

public class MainBankAccount {
	public static void main(String[] args) {
		
		BankAccount sbAccount = new BankAccount(123654,"Savings Bank", 50000.00f);
		RDAccount    rdAccount = new RDAccount(963258741,"Recurring Deposit", 75000.00f,60);
		
		sbAccount.showBalance();
		
		rdAccount.showBalance();// method is in super class BankAccount
		rdAccount.showTenure();// sub class method
		
		sbAccount.updateBalance(8.1f);
		
		rdAccount.updateBalance(12.0f);
		
		sbAccount.showBalance();
		
		rdAccount.showBalance();
		
	}
}
