package com.mycom.inheritance;

public class Rectangle extends Shape {
	int length,breadth;

	@Override
	public void computeArea() {
		// TODO Auto-generated method stub
		param = 2;
		length = param;
		breadth = 6;
		
		area = length * breadth;
	}
	
	
}
