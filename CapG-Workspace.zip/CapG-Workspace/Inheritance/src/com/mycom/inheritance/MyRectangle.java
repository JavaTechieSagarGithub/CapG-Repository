package com.mycom.inheritance;

public class MyRectangle implements IShape{ 
	int length, breadth, area;

	public void computeArea() {
		// TODO Auto-generated method stub
		length=10;
		breadth=7;
		area = length * breadth;
	}

	public void showArea() {
		// TODO Auto-generated method stub
	System.out.println("Area of Rectangle : " + area);	
	}
	

}
