package com.mycom.inheritance;

public class MyCircle implements IShape{
	int radius;
	float area;
	public void computeArea() {
		// TODO Auto-generated method stub
		radius=2;
		area = (float) (Math.PI * radius * radius);
		
	}

	public void showArea() {
		// TODO Auto-generated method stub
		System.out.println("Area of circle = " + area);
	}

}
