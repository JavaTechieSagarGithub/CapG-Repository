

public class Test{
   public static void main(String args[]){
      String str = new String("Welcome to Java World!!");

      System.out.print("Return Value :" );
      System.out.println(str.matches("^[a-z]$"));

      System.out.print("Return Value :" );
      System.out.println(str.matches("Java"));

      System.out.print("Return Value :" );
      System.out.println(str.matches("Welcome(.*)"));
   }
}