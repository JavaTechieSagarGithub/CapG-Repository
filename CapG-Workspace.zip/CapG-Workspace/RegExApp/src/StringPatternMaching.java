import java.util.regex.*;    
public class StringPatternMaching {
	public static void main(String args[]) {
		String pattern = "[a-z]+";
		       String text = "Now is the time";
		       Pattern ptrn = Pattern.compile(pattern);
		       Matcher mchr = ptrn.matcher(text);
		       while (mchr.find()) {
		    	   System.out.print(text.substring(mchr.start(), mchr.end()) + "-");
	    	   }    
   }
}
