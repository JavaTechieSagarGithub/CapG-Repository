import java.util.regex.Matcher;
import java.util.regex.Pattern;
 
public class PasswordValidator{
 
	  private Pattern pattern;
	  private Matcher matcher;
	  private String passwordPattern =  "^(?=.*[0-9])(?=.*[a-z]).{8,15}$";
	  //"^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@&()�[{}]:;',?/*~$^+<>]).{8,20}$";
	  public PasswordValidator(){
		  pattern = Pattern.compile(passwordPattern);
	  }
	  
	  	//returns true if password is valid otherwise false
	  
	 public boolean validate(String password){
 		  matcher = pattern.matcher(password);
		  return matcher.matches();
 
	  }
}