
public class MainPasswordValidator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean validPassWord=true;
		PasswordValidator pwvdtr =  new PasswordValidator();
		validPassWord = pwvdtr.validate("abcde12345");
		if (validPassWord){
			System.out.println("Valid password");
		} else  {
			System.out.println("Invalid password");
		}
	}

}
