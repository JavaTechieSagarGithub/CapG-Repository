import java.util.regex.Pattern;
import java.util.regex.Matcher;
 
public class UserNameValidator{
 
	  private Pattern pattern;
	  private Matcher matcher;
 
	  private String usernamePattern = "^[a-zA-Z$0-9_-]{4,15}$";
	  //[][] the allowed characters
	  // { , }  min and max number of occurrences of complete pattern
	  
	   
	  /*
	   * Validate username with regular expression
	   * returns true - if valid username, false if invalid username
	   */
	  public boolean validate(String username){
		  
		  pattern = Pattern.compile(usernamePattern);
		  matcher = pattern.matcher(username);
		  return matcher.matches();
 
	  }
}