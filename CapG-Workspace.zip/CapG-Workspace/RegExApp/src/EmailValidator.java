import java.util.regex.*;
 
public class EmailValidator{
 
public static void main(String[] args){
 
 String email = "checkme@youremail.com"; 
 String regEx = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";
 
 Pattern p = Pattern.compile(regEx);
 Matcher m = p.matcher(email);
 
 if(m.find()) 
 {
  System.out.println(email + " is a valid email address."); }
 else
 {
  System.out.println(email + " is a invalid email address");
 }
 }
}