public class MainUserNameValidator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// ^[a-zA-Z$0-9_-]{4,15}$
		boolean validUserName = true;

		UserNameValidator unv = new UserNameValidator();
		validUserName = unv.validate("ab$12-CapGemini");
		if (validUserName) {
			System.out.println("Valid User Name");
		} else {
			System.out.println("Invalid User Name");
	
		}
	}
}
