
public class NullPointerExcpApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="Hello";
		try {
			str=null;
			System.out.println( str.length());
		}catch(NullPointerException npexcp) {
			System.err.println( npexcp.getMessage());
		}
		

	}

}
