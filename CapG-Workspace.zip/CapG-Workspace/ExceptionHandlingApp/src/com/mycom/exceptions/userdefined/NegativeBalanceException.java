package com.mycom.exceptions.userdefined;

public class NegativeBalanceException extends Exception {
	// code goes here
	
	public NegativeBalanceException(String msg) {
		super(msg);
	}
}
