package com.mycom.exceptions.userdefined;

import java.util.Scanner;

public class WithdrawApp {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		float balance,withdrawAmount;
		System.out.println("Enter Current balance"); 
		balance = scnr.nextFloat();
		System.out.println("Enter withdrawl amount");
		withdrawAmount = scnr.nextFloat();
		
		if ( ( balance - withdrawAmount ) < 0 ) {
			try {
				throw new NegativeBalanceException("Withdrawl amount should be less than or equal to available balance");
			} catch (NegativeBalanceException e) {
				// TODO Auto-generated catch block
				System.err.println( e.getMessage() );
				System.exit(0);// program terminates successfully
			}
			
		}
		System.out.println("Available balance is "  + ( balance - withdrawAmount));

	}

}
