package com.mycom.exceptions.userdefined;

import java.io.IOException;

public class PrintStackTraceFinder {

	public static void main(String[] args)  {
		try {
			m1();
		} catch(IOException ioe) {
			ioe.printStackTrace();
		}

	}
	static void m1() throws IOException {
		m2();
	}
	static void m2() throws IOException {
		m3();
	}
    static void m3() throws IOException {
    	throw new IOException();
    }
}
