
public class NumberFormatExcpApp {

	public static void main(String[] args) {
		String mobileNo = "987-987-9871";// occupies 2*10 = 20 bytes
		try {
			long mobNo = Long.parseLong( mobileNo );// converts string into long type - occupies 8 bytes
			System.out.println("Mobile no after converting into long type : " + mobNo);
		} catch(NumberFormatException nfexcp) {
			
			System.err.println( nfexcp.getMessage() );
			
		} finally {
			System.out.println("In the finally block");
		}
		
		//long mobNo2 = Long.parseLong( mobileNo );// converts string into long type - occupies 8 bytes
		
		
		
	}

}
