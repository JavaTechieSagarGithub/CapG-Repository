
public class Rectangle implements IShape {
	float length, breadth, area;
	@Override
	public void computeArea() {
		length = 2.15f;
		breadth = 65.23f;
		area = length * breadth;
		
	}

	@Override
	public void showArea() {
		System.out.println( " Area of Rectangle =  " + area);
		
	}

}
