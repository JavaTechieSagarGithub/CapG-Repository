
public class MyCompany  implements ICompany {

	@Override
	public void recruitEmployees() {
		System.out.println(  ICompany.COMPANY_NAME + 
				" recurits employees");
			}

	@Override
	public void appraisals() {
		// TODO Auto-generated method stub
		}
	

}
