
public interface IShape {
	
    void computeArea();
	void showArea();
	
}
