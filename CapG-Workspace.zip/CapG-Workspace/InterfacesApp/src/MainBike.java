
public class MainBike {

	public static void main(String[] args) {
		
		 HondaBike shine = new HondaBike();
		 shine.showBrandName();
		 shine.showCc();

	}

}
