
public class HondaBike implements TwoWheeler, MotorCycle {
	String brandName;
	int cc;
	@Override
	public void showBrandName() {
		brandName = "Honda Shine 125 SP";
		System.out.println("Brand name = " + brandName);
	}

	@Override
	public void showCc() {
		cc = 125;
		System.out.println(" Bike is of   " + cc  + "CC");
	
		
	}

}
