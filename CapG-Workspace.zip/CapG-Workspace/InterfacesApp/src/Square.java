
public class Square implements IShape {
	float side,area;
	@Override
	public void computeArea() {
		// TODO Auto-generated method stub
		
		side = 5.0f;
		area = side * side; 
		
	}

	@Override
	public void showArea() {
		// TODO Auto-generated method stub
		System.out.println("Area of square = " + area);
	}

}
