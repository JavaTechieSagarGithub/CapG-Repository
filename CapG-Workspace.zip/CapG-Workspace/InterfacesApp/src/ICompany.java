
public interface ICompany {
	public static final String COMPANY_NAME="HCL";
	public static final long TOLLFREE_NO = 180036251456L;
	
	void recruitEmployees();
	void appraisals();

}
