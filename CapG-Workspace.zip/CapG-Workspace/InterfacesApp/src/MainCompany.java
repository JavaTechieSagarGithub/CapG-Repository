
public class MainCompany {

	public static void main(String[] args) {
		MyCompany myCompany = new MyCompany();
		myCompany.recruitEmployees();

	}

}
