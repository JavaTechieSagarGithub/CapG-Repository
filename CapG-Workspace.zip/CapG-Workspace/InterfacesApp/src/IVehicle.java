
public interface IVehicle {
	
	// all are the abstract methods. 
    void changeGear(int gearNo); 
    void speedUp(int speed); 
    void applyBrakes(int reduceSpeed); 
}
