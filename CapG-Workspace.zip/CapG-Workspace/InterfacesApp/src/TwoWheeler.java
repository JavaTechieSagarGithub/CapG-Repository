
public interface TwoWheeler {
	void showCc();

}
