package com.mycom.bank.rewardpoints;


public class HPVISACard extends VISACard {

    public Double computeRewardPoints(String type, Double amount){
    	super.computeRewardPoints(type, amount);
    	if (type.equalsIgnoreCase("fuel")){
    		return ((super.getReward())+10);
    	}
    	else{
    		return super.getReward();
    	}
        
    }
}
