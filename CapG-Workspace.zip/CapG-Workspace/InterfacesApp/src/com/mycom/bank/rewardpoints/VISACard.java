package com.mycom.bank.rewardpoints;

public class VISACard {
    private Double reward;
	
	public Double getReward() {
		return reward;
	}

	public void setReward(Double reward) {
		this.reward = reward;
	}

	public Double computeRewardPoints(String type, Double amount){
		this.setReward(amount*0.01);
        return reward;
    }
	
}
