
public class MainVehicle {

	public static void main(String[] args) {
		// creating an instance of Bicycle  
		System.out.println("Bicycle present state :"); 
        Bicycle bicycle = new Bicycle(); 
        bicycle.changeGear(2); 
        bicycle.speedUp(5); 
        bicycle.applyBrakes(1); // reduces speed by 1kmph
          
        
        bicycle.printStates(); 
        System.out.println("\n\n\nBike present state :");   
        // creating instance of the bike. 
        Bike bike = new Bike(); 
        bike.changeGear(1); 
        bike.speedUp(10); 
        bike.applyBrakes(3); // reduces speed by 3 kmph
          
        
        bike.printStates(); 

	}

}
