
public class StateBankAccount  implements IAccount  {
	
	double balance;

     public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        balance -= amount;
    }
}
