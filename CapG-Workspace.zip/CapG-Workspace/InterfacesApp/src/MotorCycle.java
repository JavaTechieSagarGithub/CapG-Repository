
public interface MotorCycle {
	void showBrandName();

}
