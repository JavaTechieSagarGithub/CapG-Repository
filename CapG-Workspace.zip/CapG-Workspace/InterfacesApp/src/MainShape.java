
public class MainShape {

	public static void main(String[] args) {
		Circle circle = new Circle();
		Rectangle rectangle = new Rectangle();
		
		circle.computeArea();
		circle.showArea();
		
		rectangle.computeArea();
		rectangle.showArea();

	}

}
