package com.mycom.testsuite;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import junit.framework.TestCase;

public class TestLargestElement extends TestCase {

	@Test
	public void testFindLargest() {
		assertFalse(2 > 3);
		assertTrue(6 > 2);
	}

}
