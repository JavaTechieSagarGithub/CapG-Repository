package com.mycom.testsuite;

import org.junit.runner.Result;

import org.junit.runner.JUnitCore;
import org.junit.runner.notification.Failure;

public class MainTestApp {

	public static void main(String[] args) {
		Result result = JUnitCore.runClasses( TestLargestElement.class, TestSmallestElement.class );
		
		int failures = 0;
	    for (Failure failure : result.getFailures()) { // iterates through all failures
	      System.out.println(failure.toString());
	      failures++;
	        
	    }
	 
	    if (failures == 0 ) {
	    	System.out.println("The app passed all test cases");
	    }
	    else {
	    	System.err.println(failures + " test cases  failed in the app! Please retest the app! ");
	    }
	}

}
