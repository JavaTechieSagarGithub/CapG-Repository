package com.mycom.junit.normal;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestMaxElementFinder {

	@Test  
    public void testFindMax(){  
		
		MaxElementFinder maxElmFinder = new MaxElementFinder();
		int scores[] = { -1,53,-4,-10,-2 }; // test data
		int max = maxElmFinder.findMax( scores );
		
        assertEquals(53, maxElmFinder.findMax(scores) ); 
        
        //assertEquals(-1, maxElmFinder.findMax(scores) );  
    }  
	
}
