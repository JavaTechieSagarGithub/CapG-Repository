package com.mycom.junit.normal;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import junit.framework.TestCase;

public class TestArrayEquals extends TestCase  {

		@Test 
			
		public void testArrays() {
			
			 String[] expectedOutput = {"apple", "mango", "grape"};
		     String[] methodOutput = {"apple", "mango", "grape"};
		     
		     assertArrayEquals(expectedOutput, methodOutput);
		}
}
