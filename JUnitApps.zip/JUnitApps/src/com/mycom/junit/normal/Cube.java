package com.mycom.junit.normal;

public class Cube {
	
	public static int findCube(int num) {  
		
		        return num*num*num;  
		
	}  

}
