package com.mycom.junit.normal;

import java.util.Scanner;

public class AdminStringReader {
	String username;
	Scanner scnr = new Scanner(System.in);
	
	public String readString() {
		System.out.println("Enter string as admin");
		username = scnr.nextLine();//type admin
		return this.username;
	}
}
