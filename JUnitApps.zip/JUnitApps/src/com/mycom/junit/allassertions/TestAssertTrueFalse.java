package com.mycom.junit.allassertions;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

public class TestAssertTrueFalse {
	@Test
	  void testAssertTrueAndFalse() {
	        assertTrue(2 < 3);
	        assertFalse(2 > 3);
	  }
}
