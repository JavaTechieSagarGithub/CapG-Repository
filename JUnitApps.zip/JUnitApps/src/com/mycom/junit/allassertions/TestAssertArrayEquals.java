package com.mycom.junit.allassertions;

import static org.junit.Assert.assertArrayEquals;

import org.junit.jupiter.api.Test;

public class TestAssertArrayEquals {
	@Test
	public void myTestMethod() {
		
		String[] expectedOutput = { "apple", "mango", "grape" };
		
		String[] methodOutput = { "apple", "mango", "grape" };
		assertArrayEquals(expectedOutput, methodOutput);
	}
}
