package com.mycom.junit.allassertions;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;

public class TestAssertNullNotNull {
	 @Test
	  void testAssertNullAndNotNull() {
	      String nullObject = null;
	      String nonNullObject = "Java is fun";
	      assertNull(nullObject);
	      assertNotNull(nonNullObject);
	  }
}
