package com.mycom.bankbalance;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import junit.framework.TestCase;

public class AssertAllMethods extends TestCase { 
	 //Variable declaration		
    String string1;					
    String string2;		
    
    String string3;					
    String string4;	
    
    String string5;		
    
    int variable1;					
    int variable2;		
    
    int grades1[] = { 1,2,3 }; 				
    int grades2[] = { 1,2,3 };
    
	public void setUp() {
		 //Variable declaration		
        string1="Junit";					
        string2="Junit";		
        
        string3="test";					
        string4="test";	
        
        string5=null;		
        
        variable1=1;					
        variable2=2;		
        
               		
	}
	
	@Test		
    public void testAssert(){					
        		
       
        //Assert statements		
        assertEquals(string1,string2);		
        
        assertSame(string3, string4);		//true 	
        
        assertNotSame(string1, string3);		
        
        assertNotNull(string1);			
        
        assertNull(string5);			
        
        assertTrue(variable1<variable2);	
        
        assertArrayEquals( grades1, grades2 );		
       
    }		
}		



